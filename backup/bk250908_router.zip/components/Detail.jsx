function Detail() {
  return (
    <>
      <h2>상세 페이지</h2>
    </>
  )
}

export default Detail;